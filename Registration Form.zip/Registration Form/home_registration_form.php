<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>WELCOME TO OUR WEBSITE</h1>
        <p>Click below to Register.</p>
        <div class="items">
            <a href="Registration Form.php">
                <button type="button" class="btn">INSTRUCTORS</button>
            </a>
            <a href="Registration Form Student.php">
                <button type="button" class="btn">STUDENTS</button>
            </a>
        </div>
    </div>
</body>
</html>